const app = getApp();
const defaultScale = 14;
var consoleUtil = require('../../utils/consoleUtil.js');
var constant = require('../../utils/constant.js');
var QQMapWX = require('../../libs/qqmap-wx-jssdk.js');
//var datalist=[];
//var datalist = require('./data.js');
//定义全局变量
var wxMarkerData = [];
var bottomHeight = 0;
var windowHeight = 0;
var windowWidth = 0;
var mapId = 'myMap';
var qqmapsdk;

var sizeType = [
  ['compressed'],
  ['original'],
  ['compressed', 'original']
]

Page({
  data: {
    userInfo: {},
    hasUserInfo: false,
    personalizedCallback: false,

    InfoAuth:false,           //基本信息授权：false
    LocaAuth:false,           //地理位置授权：false
    showAuthorPage: true,    //是否显示授权界面

    //地图缩放级别


    ////////当前工作：“添加好友”弹窗/////////////////////////////////////
    showaddFriend:true,            //是否显示弹窗
    addable:false,                 //“添加好友”是否可点击
    searched_friend:{},              //搜索的好友（一个对象，包括searchID、昵称等基本信息)
    result_nickName:" ",           //搜索结果_用户昵称
    result_avatarUrl:" ",          //搜索结果_用户头像
    ///////////////////////////////////////////////////////////////////


    currentFriend: {        //8.15修改：当前好友对象（currentFriend）
      wxid: "",
      name: "王境泽",
      latitude: 31.2303722,
      longitude: 121.4732,
    },

    friendmarkers: [

    ],

    //8.14修改：
    showFriend: false,

    //8.14修改：好友列表（空数组），用的时候动态添加
    friendList: [
      //{wxid:"",name:"我",signature:"不愧是我~",latitude:31.23037112,longitude:121.4787},
      // { wxid: "", name: "王境泽", signature: "真香教父", latitude: 31.23037162, longitude: 121.4726 },
      // { wxid: "", name: "赵日天", signature: "断罪小学", latitude: 31.23837152, longitude: 121.4739 },
      // { wxid: "", name: "王大锤", signature: "万万没想到", latitude: 31.23037832, longitude: 121.4732 }

    ],

    longitude: '',
    latitude: '',
    searchResult: {},
    //地图缩放级别
    scale: defaultScale,
    locationMarkers: [],
    flag: false,
    markers: [{
      longitude: 121.38206,
      latitude: 31.113066075190382,
      //id:1,
      width: 60,
      height: 60,
      iconPath: '../../img/me.png',
      callout: {
        content: "My Location", //文本
        color: 'pink', //文本颜色
        borderRadius: 7, //边框圆角
        borderWidth: 1, //边框宽度
        //borderColor: 'white', //边框颜色
        bgColor: 'white', //背景色
        padding: 5, //文本边缘留白
        textAlign: 'center', //文本对齐方式。有效值: left, right, center
        display: "ALWAYS"
      }
    }
      //friend图钉

    ],

    showTopTip: true,
    warningText: '顶部提示',
    showUpload: true,
    showConfirm: false,
    showComment: false,
    showPersonalizedLocation: false,
    //地图高度
    mapHeight: 0,
    infoAddress: '',
    commentCount: 0,
    praiseCount: 0,
    commentList: [],
    selectAddress: '',
    centerLongitude: '',
    centerLatitude: '',
    uploadImagePath: '',
    currentMarkerId: 0,

    warningIconUrl: '',
    infoMessage: '',
    isUp: false,
    //中心指针，不随着地图拖动而移动
    controls: [],
    //搜索到的中心区域地址信息,用于携带到选择地址页面
    centerAddressBean: null,
    //选择地址后回调的实体类
    callbackAddressInfo: null,
    //将回调地址保存
    callbackLocation: null,
    //当前省份
    currentProvince: '',
    //当前城市
    currentCity: '',
    //当前区县
    currentDistrict: '',
    showHomeActionIcon: true,
    homeActionLeftDistance: '0rpx',
    //单个 marker 情报
    currentTipInfo: '',


  },


//9.21修改：用户授权
bindGetUserInfo: function(e) {
  let that = this;
  wx.showLoading({            //先显示正在加载
    title: '正在授权',
  })

  // 获取用户信息
  //实现逻辑：先执行getUserInfo方法，获取基本信息，成功后调用success回调函数
  //在其success内部调用getLocation方法，获取地址信息
  //之所以要用嵌套的方法，是为了避免异步带来的困扰
  wx.getSetting({
   success(res) {

    //获取用户位置(必须在这里获得)
    var scopeUserInfo=res.authSetting['scope.userInfo'];
    var scopeUserLocation=res.authSetting['scope.userLocation'];    

    //////////////////////////1.获取用户的基本信息授权//////////////////////////
    if (scopeUserInfo) {
     console.log("已授权基本信息=====")

     wx.getUserInfo({     // 已经授权，可以直接调用 getUserInfo 
      success(res) {

        let BasicInfo=res;       //将用户基本信息存入BasicInfo对象中
        console.log("打印getUsetInfo中的res————————————————————————");
    console.log(BasicInfo);

       console.log("获取用户信息成功", res)
       that.setData({
        InfoAuth:true,       //将用户信息授权改为true
       })
    
         ///////////// 2.获取用户的地理位置授权(嵌套在getUserInfo内部)/////////////////////
    if (scopeUserLocation) {
      console.log("已授权位置信息=====")      

      wx.getLocation({
       success(res) {         //如果成功

        let LocaInfo=res;     //将地址信息存入LocaInfo中
        console.log("打印getLocation中的res————————————————————————");
        console.log(LocaInfo);

        console.log("获取地理信息成功", res)
       that.setData({
          LocaAuth:true,       //将用户信息授权改为true
        })
       


        if((that.data.InfoAuth)&&(that.data.LocaAuth)){          //如果基本信息授权、地址信息授权均已完成，则不再显示授权页面
          that.setData({
           showAuthorPage:false
          })
          console.log("进到了最后的条件判断内！1111111");
          
          console.log(that.data.showAuthorPage)

           ///////////////在这里进行用户信息的判断和写入！！///////////////////////////
       //////////////1.先获取用户的openId，在后台进行判断/////////////////////////
       //////////////2.如果已有：则读取对应信息，显示到界面上//////////////////////
       //////////////3.如果没有，则将用户信息写入数据库中//////////////////////////
       console.log("打印openID————————————————————————————————————————————-");
       console.log(BasicInfo.userInfo.avatarUrl);
       console.log(BasicInfo.userInfo.nickName);
       console.log(LocaInfo.latitude);
       console.log(LocaInfo.longitude);


       //调用云函数，获取openID
       wx.cloud.callFunction({      
         name:"login",              //云函数方法名
         data:{                     //传递给云函数的数据,包括：昵称，头像，经纬度
           nickName:BasicInfo.userInfo.nickName,
           avatarUrl:BasicInfo.userInfo.avatarUrl,
           latitude:LocaInfo.latitude,
           longitude:LocaInfo.longitude
         }
       })
       .then(res=>{
         console.log(res)         //打印获取到的参数
         console.log("现在打印云函数返回的信息res！！！！！！！！！！！")
         console.log("res："+res);
       })
        }
       },


       fail(res) {            //如果失败
        console.log("获取位置信息失败", res)
        wx.showToast({
          title: '获取位置信息失败'
        })
       }
      })
     } else {
      console.log("未授权=====")
      that.showSettingToast("请授权位置信息")
     }

     
      },
      fail(res) {           
       console.log("获取用户信息失败", res)
       wx.showToast({
         title: '获取用户信息失败',
         icon:'none'
       })
      },
      complete(res){           //执行完毕(不管成功or失败)
        wx.hideLoading()        //关闭加载界面
    }
     })
    } else {
     console.log("未授权=====")
     that.showSettingToast("请授权基本信息")
     wx.hideLoading()           //关闭加载界面
    }

   }
  })

 },
 
 // 打开权限设置页提示框
 showSettingToast: function(e) {
  wx.showModal({
   title: '提示！',
   confirmText: '去设置',
   showCancel: false,
   content: e,
   success: function(res) {
    if (res.confirm) {
     wx.openSetting({
       withSubscriptions: true,
     })
    }
   }
  })
 },

/////////////////////////////////////////////////////////////////////////////////////////
    /////////////当前工作：好友列表的读取与渲染//////////////////////////////////////////////

/**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.cloud.callFunction({
      name:"testFunction"
    })

    wx.cloud.callFunction({
      name:"readFriendList"
    })
    .then(res=>{
      console.log("好友列表读取成功！打印返回信息————————————————");
      console.log(res);
    })
    .catch(err=>{
      console.log("好友列表读取失败。。。打印返回信息————————————————");
      console.log(err);    
    })
  },
    

/**
   * 生命周期函数--监听页面显示
   */
    onShow:function(){
      wx.cloud.callFunction({
        name:"readFriendList"
      })
      .then(res=>{
        console.log("好友列表读取成功！打印返回信息————————————————");
        console.log(res);
      })
      .catch(err=>{
        console.log("好友列表读取失败。。。打印返回信息————————————————");
        console.log(err);    
      })
    },
    

    /////////////////////////////////////////////////////////////////////////////////////////
    /////////////////////////////////////////////////////////////////////////////////////////
  



  // 8.14修改：显示好友列表函数
  showFriendList: function () {

    console.log("进入好友列表显示函数");
    this.setData({ 
      showFriend: !this.data.showFriend ,   //翻转显示状态
      showPersonalizedLocation: false,       //收起扩展下拉菜单
        showaddFriend:false,             //隐藏“添加好友”弹窗
          addable:false,                //清空弹窗查询数据
          searched_friend:{},              
          result_avatarUrl: '',
          result_nickName:''
    });
  },

//////////////////////////////////////////////////////////////////////////////////////////////////
  /////////////////当前工作:“添加好友”弹窗////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////
  // 8.14修改：addFriend函数
  open_addFriend: function () {           //TODO：补充addFriend接口
    console.log("进入了addFriend函数！！！！");
    this.setData({
      showaddFriend:!this.data.showaddFriend ,                       //显示添加好友弹窗
    })
    console.log(`showaddFriend当前的状态是：${this.data.showaddFriend}`);
  },


//在数据库中查找对应searchID的好友
//查找成功后：显示其头像和昵称，点击添加即可将其添加到好友列表中

  searchFriend: function(e){
    //如果输入区无内容，直接退出函数
    if(e.detail.value==""){
      this.setData({        //清空搜索数据
        addable:false,
        searched_friend:{},              
        result_avatarUrl: '',
        result_nickName:''
      })
      return;
    }

    console.log("进入了searchFriend函数——————————————");
    console.log("输入框内的值为："+e.detail.value);

    //调用云函数,查询对应searchID是否在数据库中
    wx.cloud.callFunction({      
      name:"searchFriend",                 //云函数方法名
      data:{                            //传递给云函数的数据:输入框内的值
        searchValue:e.detail.value
      }
    })
    .then(res=>{
      console.log("现在打印res.errMessage__________");
      // console.log(res.result.errMessage);
      console.log("现在打印res——————————————————————");
      console.log(res);
      console.log("打印完毕—————————————————————————");

      //若没有搜索结果
      if(res.result.errMessage===0){             
          console.log("无搜索结果");
          this.setData({
            addable:false,
            searched_friend:{},             //搜索的好友置空
            result_avatarUrl:'../../img/icecream.png',
            result_nickName:'无搜索结果'
          })

          return;             //返回
      }

      //若查询操作失败
      else if(res.result.errMessage===-1){
        console.log("查询失败");
        this.setData({
          addable:false,
          searched_friend:{},              //搜索的好友置空
          result_avatarUrl:'../../img/fail.png',
            result_nickName:'服务异常，查询失败'
        })
      }

      //如果查询成功
      else if((res.result.errMessage==1)||(res.result.errMessage==2)){
      console.log("现在打印搜索到的好友信息！！！！！！！");
      console.log(res);
      console.log("打印完毕！！！！！！！！！！！！！！！");

      //设置相关信息
      this.setData({
        addable:true,
        searched_friend:res.result,            
        result_avatarUrl:res.result.avatarUrl,
        result_nickName:res.result.nickName
      })

      //如果搜索结果是自己
      if(res.result.errMessage==2)   
      {
        //不可添加
          this.setData({    
            addable:false,
          })
      }
      
    }
    })
    
  },

  //添加好友函数
  addFriend:function(e){
    console.log("已进入添加好友函数————————————————————");
    console.log("接收的参数:");
    console.log(e.currentTarget.dataset.friend);

    wx.showLoading({            //先显示正在添加
      title: '正在添加',
    })

    wx.cloud.callFunction({      
      name:"addFriend",                 
      data:{                  //参数：friend对象
        friend:e.currentTarget.dataset.friend,
      }
    }).then(res=>{            //成功后
      console.log("添加成功，返回信息：————————————————");
      console.log(res);
      wx.hideLoading();       //隐藏加载框
      wx.showToast({          
        title: '添加成功',
        icon:'success'
      })
    }).catch(err=>{         //失败后
      console.log("添加失败，错误信息：————————————————");
      console.log(err);
      wx.hideLoading();     //隐藏加载框
      wx.showToast({
        title: '操作失败',
        icon:'none'
      })
    })
    
  },

  // setValue: function (e) {
  //   this.setData({
  //     walletPsd: e.detail.value
  //   })
  // },
  // cancel: function () {
  //   var that = this
  //   that.setData({
  //     showaddFriend: false,
  //   })
  // },
  // confirmAcceptance:function(){
  //   var that = this
  //   that.setData({
  //     showaddFriend: false,
  //   })
  // },
  
  // /* 弹出框蒙层截断touchmove事件
  // */
  // preventTouchMove: function () {
  // },

//////////////////////////////////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////

  //8.14修改：friend的构造函数
  friend: function (wxid, name, latitude, longitude, address) {
    this.address = address;       //地址
    this.longitude = longitude;   //经度
    this.latitude = latitude;   //纬度
    this.wxid = wxid;       //微信id
    this.name = name;     //好友名字
  },

  //8.15修改：setCurrentFriend函数：用来设置当前好友，在触发clickItem后调用

  setCurrentFriend: function (e) {
    console.log(e.currentTarget.dataset.wxid);
    console.log(e.currentTarget.dataset.name);
    console.log(e.currentTarget.dataset.latitude);
    console.log(e.currentTarget.dataset.longitude);
    this.setData({
      'currentFriend.wxid': e.currentTarget.dataset.wxid,    //1.设置currentFriend信息
      'currentFriend.name': e.currentTarget.dataset.name,
      'currentFriend.latitude': e.currentTarget.dataset.latitude,
      'currentFriend.longitude': e.currentTarget.dataset.longitude,

    });
  },



  //8.14修改：clickItem函数（点击Item的响应函数）
  clickItem: function (e) {

    this.setData({ showFriend: false,
      showPersonalizedLocation: false, //hide more menu
      showConfirm: false,              
      showaddFriend:false,             //隐藏“添加好友”弹窗

        addable:false,                //清空弹窗查询数据
        searched_friend:{},              
        result_avatarUrl: '',
        result_nickName:''
    });   //点击Item后，收起列表

    console.log("进入了clickItem");
    this.setCurrentFriend(e);          //设置当前好友

    this.setData(              //地图位置跳转
      {
        latitude: e.currentTarget.dataset.latitude,
        longitude: e.currentTarget.dataset.longitude,
        scale: 18,         //缩放
      },
    );
    console.log(e.currentTarget.dataset.latitude);
    console.log(e.currentTarget.dataset.longitude);
    // that.updateCenterLocation(e.currentTarget.dataset.latitude, e.currentTarget.dataset.longitude);
  },



  //}, !!

  moveTolocation: function () {
    var mapCtx = wx.createMapContext(mapId);
    mapCtx.moveToLocation();
  },

  onLoad: function (options) {
    var that = this;
    this.bindGetUserInfo();         //在加载时，自动进行授权验证

    if (app.globalData.userInfo) {
      consoleUtil.log(11111);
      this.setData({
        userInfo: app.globalData.userInfo,
        hasUserInfo: true
      })

      console.log("进入了userifo---------------------------");
      console.log(app.globalData.userInfo);

    } else {
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      consoleUtil.log(22222);
      app.userInfoReadyCallback = res => {
        consoleUtil.log(33333);
        app.globalData.userInfo = res.userInfo;
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    }
    that.scopeSetting();

  },

  onShow: function () {
    consoleUtil.log('onShow--------------------->');

    var that = this;
    that.changeMapHeight();

    wx.cloud.init();
    wx.cloud.callFunction({
      name: 'importData',
      complete: res => {
        console.log('callFunction test result: ', res)
        if (this.data.locationMarkers.length <= 1) {
          console.log("+++++++++++++++++++++")
          this.showPointsTwo(res.result.data);
        }

        // console.log(this.data.datalist);
      }
    })

    consoleUtil.log(that.data.callbackAddressInfo)
    if (that.data.callbackAddressInfo == null) {
      that.getCenterLocation();
      //正在上传的话，不去请求地理位置信息
      if (that.data.showUpload) {
        that.requestLocation();
      }
    } else {
      that.setData({
        selectAddress: that.data.callbackAddressInfo.title,
        callbackLocation: that.data.callbackAddressInfo.location,
        latitude: that.data.callbackAddressInfo.location.lat,
        longitude: that.data.callbackAddressInfo.location.lng
      })
      if(that.data.personalizedCallback){
        // var currentMarkers=that.data.locationMarkers;
        // currentMarkers[0].latitude=that.data.latitude;
        // currentMarkers[0].longitude=that.data.longitude;
        that.setData({
          'locationMarkers[0].latitude':that.data.latitude,
          'locationMarkers[0].longitude':that.data.longitude,
        })
      }
      that.updateCenterLocation(that.data.callbackLocation.lat, that.data.callbackLocation.lng);
      //that.moveTolocation();
      //置空回调数据，即只使用一次，下次中心点变化后就不再使用
      that.setData({
        callbackAddressInfo: null,
        personalizedCallback: false
      })
    }
  },

  /**
   * 页面不可见时
   */
  onHide: function () {

  },

  /**
   * 点击顶部横幅提示
   */
  showNewMarkerClick: function () {

    var that = this;
    that.setData({
      showFriend:false,                                               //收起好友列表
      showPersonalizedLocation: !(that.data.showPersonalizedLocation) //显示扩展下拉菜单
    })


  },
  //convert data in datalist to markers
  showPoints: function (datalist) {
    var that = this;
    var markerList = that.data.markers;
    //8.16修改：将friendlist好友列表中的元素加到marker数组中
    for (let index = 0; index < this.data.friendList.length; index++) {
      let modelMarker = {              //marker模板
        iconPath: '../../img/you.png',
        width: 40,
        height: 40,
        latitude: 31.23844131,
        longitude: 121.471131,
        nickName: "我",
        callout: {
          content: '是我~',
          color: '#fff',
          fontsize: 15,
          borderRadius: 10,
          bgColor: '#333',
          padding: 5
        },
        label: {
          content: '小明', color: '#333',
          anchorX: 0, anchorY: 0,
          borderWidth: 1, borderColor: '#000', borderRadius: 5,
          bgColor: '#fff', padding: 2, textAlign: 'center'
        }
      };
      //将模板marker的属性，改成相应好友的属性，得到对应好友的marker
      modelMarker.latitude = this.data.friendList[index].latitude;
      modelMarker.longitude = this.data.friendList[index].longitude;
      modelMarker.name = this.data.friendList[index].nickName;
      modelMarker.label.content = this.data.friendList[index].nickName;
      modelMarker.callout.content = this.data.friendList[index].signature;
      console.log(modelMarker.latitude);
      console.log(modelMarker.longitude);
      console.log(modelMarker.latitude);
      console.log(modelMarker.latitude);
      markerList.push(modelMarker);//!!!!
      console.log("现在marker数组的长度是：" + markerList.length);
      // console.log("已将"+this.data.friendList[index].name+"添加到数组中，"+"现在数组长度为："+this.data.friendmarkers.length);
      // console.log("纬度："+this.data.friendmarkers[index].latitude+"经度："+this.data.friendmarkers[index].longitude);
    }//end for loop




    for (var event of datalist) {

      var searchkey = event.venue;
      var searchCity = event.venuecity;
      var name = event.name;
      var time = event.showtime;
      that.suggestionSearch(searchkey, searchCity, name, time).then(
        result => {
          var currentmarker = {
            latitude: result.location.lat,
            longitude: result.location.lng,
            width: 50,
            height: 50,
            iconPath: '../../img/bulb.png',
            callout: {
              content: result.eventName + '\n' + '\n' + result.showTime + '\n' + '\n' + result.address,
              borderRadius: 15,  //边框圆角
              borderWidth: 0,//边框宽度
              padding: 5,
              bgColor: "#715C88",
              color: "#ffffff",
              textAlign: 'center',
              /*
              color:'#E5958E',
              bgColor:'ffffff'*/

            }
          }

          markerList.push(currentmarker);
          console.log(currentmarker);

          this.setData({
            locationMarkers: markerList
          })
          console.log(this.data.locationMarkers)

        }
      )
    }
    this.setData({
      scale: 14
    })
  },

  suggestionSearch: function (searchValue, city, eventname, showtime) {
    return new Promise((resolve, reject) => {
      var that = this;
      consoleUtil.log(qqmapsdk);
      qqmapsdk.getSuggestion({
        keyword: searchValue,
        region: city,
        region_fix: 1,
        policy: 1,
        success: function (res) {
          console.log("bilbilbil");
          console.log(res.data[0]);
          res.data[0].eventName = eventname;
          res.data[0].showTime = showtime;
          res.data[0].address = searchValue;
          //return res.data[0];
          resolve(res.data[0])
        },
        fail: function (res) {
          console.log(res);
          //return {};
          reject();
        }
      });
    });
  },

  showPointsTwo: function (datalist) {
    var that = this;
    this.setData({
      locationMarkers: this.data.markers
    })
    //8.16修改：将friendlist好友列表中的元素加到marker数组中
    for (let index = 0; index < this.data.friendList.length; index++) {
      let modelMarker = {              //marker模板
        iconPath: '../../img/you.png',
        width: 40,
        height: 40,
        latitude: 31.23844131,
        longitude: 121.471131,
        name: "我",
        callout: {
          content: '是我~',
          color: '#fff',
          fontsize: 15,
          borderRadius: 10,
          bgColor: '#333',
          padding: 5
        },
        label: {
          content: '小明', color: '#333',
          anchorX: 0, anchorY: 0,
          borderWidth: 1, borderColor: '#000', borderRadius: 5,
          bgColor: '#fff', padding: 2, textAlign: 'center'
        }
      };
      //将模板marker的属性，改成相应好友的属性，得到对应好友的marker
      modelMarker.latitude = this.data.friendList[index].latitude;
      modelMarker.longitude = this.data.friendList[index].longitude;
      modelMarker.name = this.data.friendList[index].name;
      modelMarker.label.content = this.data.friendList[index].name;
      modelMarker.callout.content = this.data.friendList[index].signature;
      console.log(modelMarker.latitude);
      console.log(modelMarker.longitude);
      console.log(modelMarker.latitude);
      console.log(modelMarker.latitude);
      this.data.locationMarkers.push(modelMarker);//!!!!
      console.log("现在marker数组的长度是：" + this.data.locationMarkers.length);
      // console.log("已将"+this.data.friendList[index].name+"添加到数组中，"+"现在数组长度为："+this.data.friendmarkers.length);
      // console.log("纬度："+this.data.friendmarkers[index].latitude+"经度："+this.data.friendmarkers[index].longitude);
    }//end for loop




    for (var event of datalist) {

      //console.log(event.location)

      var currentmarker = {
        latitude: event.lat,
        longitude: event.lng,
        //event.location.coordinates[0],
        width: 50,
        height: 50,
        iconPath: '../../img/bulb.png',
        callout: {
          content: event.name + '\n' + '\n' + event.venue + '\n' + '\n' + event.showtime,
          borderRadius: 15,  //边框圆角
          borderWidth: 0,//边框宽度
          padding: 5,
          bgColor: "#715C88",
          color: "#ffffff",
          textAlign: 'center',


        }
      }

      this.data.locationMarkers.push(currentmarker);
      console.log(this.data.locationMarkers)



    }
    this.setData({
      scale: 14,
      locationMarkers: this.data.locationMarkers
    })

  },

  changeMapHeight: function () {
    var that = this;
    var count = 0;
    wx.getSystemInfo({
      success: function (res) {
        consoleUtil.log(res);
        windowHeight = res.windowHeight;
        windowWidth = res.windowWidth;
        //创建节点选择器
        var query = wx.createSelectorQuery();
        var query = wx.createSelectorQuery();
        query.select('#bottom-layout').boundingClientRect()
        query.exec(function (res) {
          consoleUtil.log(res);
          bottomHeight = res[0].height;
          that.setMapHeight();
        })
      },
    })
  },

  setMapHeight: function (params) {
    var that = this;
    that.setData({
      mapHeight: (windowHeight - bottomHeight) + 'px'
    })
    var controlsWidth = 40;
    var controlsHeight = 48;
    //设置中间部分指针
    // that.setData({
    //   controls: [{
    //     id: 1,
    //     : '../../img/personLocation.png',
    //     position: {
    //       left: (windowWidth - controlsWidth) / 2,
    //       top: (windowHeight - bottomHeight) / 2 - controlsHeight * 3 / 4,
    //       width: controlsWidth,
    //       height: controlsHeight
    //     },
    //     clickable: true
    //   }]
    // })

  },

  scopeSetting: function () {
    var that = this;

    that.initMap();
  },

  /** 
   * 初始化地图
   */
  initMap: function () {
    var that = this;
    qqmapsdk = new QQMapWX({
      key: constant.tencentAk
    });
    that.getCenterLocation();
  },

  //请求地理位置
  requestLocation: function () {
    var that = this;
    wx.getLocation({
      type: 'gcj02',
      success: function (res) {
        if (that.data.locationMarkers.length == 0) {
          that.setData({
            'markers[0].latitude': res.latitude,
            'markers[0].longitude': res.longitude,
            latitude: res.latitude,
            longitude: res.longitude
          })

        }
        else {
          that.setData({
            latitude: res.latitude,
            longitude: res.longitude,
            'locationMarkers[0].latitude': res.latitude,
            'locationMarkers[0].longitude': res.longitude
          })
        }
        that.moveTolocation();
      },
    })
  },

  /**
   * 点击marker
   */
  bindMakertap: function (e) {
    var that = this;
    //设置当前点击的id
    that.setData({
      currentMarkerId: e.markerId
    })
    //重新设置点击marker为中心点
    for (var key in that.data.markers) {
      var marker = that.data.markers[key];
      if (e.markerId == marker.id) {
        that.setData({
          longitude: marker.longitude,
          latitude: marker.latitude,
        })
      }
    }
    wx.showModal({
      title: '提示',
      content: '你点击了marker',
      showCancel: false,
    })
  },

  /**
   * 移动视野tap
   */
  uploadInfoClick: function (e) {
    var that = this;
    that.adjustViewStatus(false, true);
    that.updateCenterLocation(that.data.latitude, that.data.longitude);
    that.regeocodingAddress();

    console.log(Number(e.currentTarget.id));
    if (Number(e.currentTarget.id) == 1) {
      that.setData({
        flag: true,
        latitude: this.data.locationMarkers[0].latitude,
        longitude: this.data.locationMarkers[0].longitude
      })
    }
    else {
      that.setData({
        flag: false
      })
    }
  },

  /**
   * 更新上传坐标点
   */
  updateCenterLocation: function (latitude, longitude) {
    var that = this;
    that.setData({
      centerLatitude: latitude,
      centerLongitude: longitude
    })
  },

  /**
   * 回到定位点
   */
  selfLocationClick: function () {
    var that = this;
    //还原默认缩放级别
    that.setData({
      scale: defaultScale
    })
    //必须请求定位，改变中心点坐标
    that.requestLocation();
  },

  /**
   * 移动到中心点
   */


  cancelClick: function () {
    var that = this;
    that.adjustViewStatus(true, false);
  },


  /**
   * 点击控件时触发
   */
  controlTap: function () {

  },

  /**
   * 点击地图时触发
   */
  bindMapTap: function () {
    //恢复到原始页

    //在点击地图时，隐藏所有列表、弹窗、下拉菜单
    this.setData(     
      {
        showFriend: false,               //隐藏好友列表
        showPersonalizedLocation: false, //hide more menu
        showConfirm: false,              
        showaddFriend:false,             //隐藏“添加好友”弹窗

          addable:false,                //清空弹窗查询数据
          searched_friend:{},              
          result_avatarUrl: '',
          result_nickName:''
      
      }
    )
    this.changeMapHeight();
    //this.adjustViewStatus(true, false, false);
  },

  adjustViewStatus: function (uploadStatus, confirmStatus) {
    var that = this;
    that.setData({
      showUpload: uploadStatus,
      showConfirm: confirmStatus
    })
    that.changeMapHeight();
  },




  onShareAppMessage: function (res) {

  },



  /**
   * 拖动地图回调
   */
  regionChange: function (res) {
    var that = this;
    // 改变中心点位置  
    if (res.type == "end") {
      that.getCenterLocation();
    }
  },

  /**
   * 得到中心点坐标
   */
  getCenterLocation: function () {


    var that = this;
    var mapCtx = wx.createMapContext(mapId);
    mapCtx.getCenterLocation({
      success: function (res) {
        console.log('getCenterLocation----------------------->');
        console.log(res);

        that.updateCenterLocation(res.latitude, res.longitude);
        that.regeocodingAddress();
        that.queryMarkerInfo();
      }
    })
  },

  /**
   * 逆地址解析
   */
  regeocodingAddress: function () {
    var that = this;
    //不在发布页面，不进行逆地址解析，节省调用次数，腾讯未申请额度前一天只有10000次
    if (!that.data.showConfirm) {
      return;
    }
    //通过经纬度解析地址
    qqmapsdk.reverseGeocoder({
      location: {
        latitude: that.data.centerLatitude,
        longitude: that.data.centerLongitude
      },
      success: function (res) {
        console.log(res);
        that.setData({
          centerAddressBean: res.result,
          selectAddress: res.result.formatted_addresses.recommend,
          currentProvince: res.result.address_component.province,
          currentCity: res.result.address_component.city,
          currentDistrict: res.result.address_component.district,
        })
      },
      fail: function (res) {
        console.log(res);
      }
    });
  },
  confirmClick: function (res) {
    var that = this;
    consoleUtil.log(res);
    var message = res.detail.value.message.trim();
    if (!that.data.centerLatitude || !that.data.centerLongitude) {
      that.showModal('请选择上传地点~');
      return;

    }
  },

  /**
   * 查询 marker 信息
   */
  queryMarkerInfo: function () {
    var that = this;
    consoleUtil.log('查询当前坐标 marker 点信息')
    //调用请求 marker 点的接口就好了
  },

  /**
   * 创建marker
   */
  // createMarker: function (dataList) {
  //   var that = this;
  //   var currentMarker = [];
  //   var markerList = dataList.data;
  //   for (var key in markerList) {
  //     var marker = markerList[key];
  //     marker.id = marker.info_id;
  //     marker.latitude = marker.lat;
  //     marker.longitude = marker.lng;
  //     marker.width = 40;
  //     marker.height = 40;

  //     marker.iconPath = '../../img/dog-select.png';


  //   }
  //   currentMarker = currentMarker.concat(markerList);
  //   consoleUtil.log('-----------------------');
  //   consoleUtil.log(currentMarker);
  //   that.setData({
  //     markers: currentMarker
  //   })
  // },

  /**
   * 选择地址
   */
  chooseAddress: function () {
    var that = this;

    this.setData({
      showConfirm: false
    })
    if (that.data.flag) {
      wx.navigateTo({
        url: '../personalizeAddress/personalizeAddress?city=' + that.data.centerAddressBean.address_component.city + '&street=' + that.data.centerAddressBean.address_component.street,
      })
    } else {
      wx.navigateTo({
        url: '../chooseAddress/chooseAddress?city=' + that.data.centerAddressBean.address_component.city + '&street=' + that.data.centerAddressBean.address_component.street,
      })
    }
    console.log("hahahahhah")
    //that.updateCenterLocation(callbackLocation.lat,callbackLocation.lng);
  },




  getUserInfo: function (e) {
    console.log("88888888888")
    console.log(e)
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  },

  
})