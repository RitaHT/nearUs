//9.25添加。此云函数用于获取用户的openID

// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init()

//数据库对象
const db=cloud.database();
const _=db.command;

// 云函数入口函数
exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext()
  console.log("测试号4................................................");
  console.log("现在打印event。。。。。。。。。");
  console.log(event);
  
  let searchValue=parseInt(event.searchValue);  
  let x=true;
  
   

  return {
    event,
    openid: wxContext.OPENID,
    appid: wxContext.APPID,
    unionid: wxContext.UNIONID,
    errMessage:"正确信息"
  }

  
}