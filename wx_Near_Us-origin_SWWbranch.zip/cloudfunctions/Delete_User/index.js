//此函数用于删除用户
//注意：删除用户时必须同时删除User_Public_Data中对应的searchID！！！
const cloud = require('wx-server-sdk')

cloud.init()

//数据库对象
const db=cloud.database();
const _=db.command;
const $=db.command.aggregate;

// 云函数入口函数
exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext()

  console.log("进入删除函数————————————————");
  console.log("测试号1")

  //删除昵称为“南风喃”的所有用户
try {
  return await db.collection('user_info').where({
    openID: wxContext.OPENID
  }).remove()
} catch(e) {
  console.log("删除失败——————————————————————");
  console.error(e);
}
}
