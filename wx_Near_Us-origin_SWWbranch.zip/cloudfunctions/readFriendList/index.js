//云函数readFriendList
//用于读取数据库中的好友列表
const cloud = require('wx-server-sdk')

cloud.init()

//数据库对象
const db=cloud.database();
const _=db.command;
const $=db.command.aggregate;


exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext()

  console.log("测试号1——————————————————————————————");

  await db.collection("user_info").where({
    openID:wxContext.OPENID
  }).get().then(res=>{
    console.log("打印get到的信息————————————————————");
      console.log(res);
  })

  return {
    event,
    openid: wxContext.OPENID,
    appid: wxContext.APPID,
    unionid: wxContext.UNIONID,
  }
}