// 云函数入口文件
const cloud = require('wx-server-sdk')

//初始化云函数
cloud.init()

//数据库对象
const db=cloud.database();
const _=db.command;


// 云函数入口函数
exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext()
  console.log("调试号：24————————————————————————————");
  console.log("现在打印event————————————————————————");
  console.log(event);
  console.log("打印完毕————————————————————————————————");
  console.log("现在打印searchValue————————————————————————");
  console.log(event.searchValue);
  console.log("打印完毕————————————————————————————————");

  //将searchID字符串转化为数字
  let searchValue=parseInt(event.searchValue);     

  //初始化用户信息变量
  let _nickName;
  let _avatarUrl;
  let _searchID;
  let _openID;
  let _latitude;
  let _longitude;

  //表示查询状态的变量
  let _errMessage;

  //在数据库中查询对应用户信息
   await db.collection('user_info').where({
    searchID:_.eq(searchValue)                              
  }).get()
  .then(res=>{
    
    console.log("现在打印res.data[0]——————————————");
    console.log(res.data[0]);
    console.log("打印完毕—————————————————————————");

    //如果搜索的用户存在
    if(res.data[0]){

      console.log("用户存在！！！！！！！！！！！！！！！！！！！！！");
      //将其存入变量
  console.log("获取成功！对应的用户信息如下：");
  console.log(res.data[0].nickName);
  console.log(res.data[0].avatarUrl);
  console.log(res.data[0].searchID);
  console.log(res.data[0].openID);
  console.log(res.data[0].latitude);
  console.log(res.data[0].longitude);
  console.log("用户信息打印完毕————————————————");

  _nickName=res.data[0].nickName;
  _avatarUrl=res.data[0].avatarUrl;
  _searchID=res.data[0].searchID;
  _openID=res.data[0].openID;
  _latitude=res.data[0].latitude;
  _longitude=res.data[0].longitude;
  _errMessage=1;

console.log("打印_openID——————————————————");
console.log(_openID);
console.log("打印wxContent.OPENID——————————————————");
console.log(wxContext.OPENID);

  //如果搜索结果是自己
  if(_openID==wxContext.OPENID){
    _errMessage=2;
    _nickName+="(是可爱的自己啦~）";
  }
    }

    else{
      console.log("用户不存在。。。。。。。。。。。。。。。。");
      _errMessage=0;
      
    }
  //查询失败
  })
  .catch(res=>{
    console.log("查询失败。。。。。。。。。。。。。。。。");
    errMessage=-1;
  })
//////////////////////////目前待解决问题：云函数返回值为空！！！！！！/////////////////////////////


    // 将用户的基本信息返回（昵称，头像，searchID，openID)
  return {
    nickName:_nickName,
    avatarUrl:_avatarUrl,
    searchID:_searchID,
    openID:_openID,
    latitude:_latitude,
    longitude:_longitude,
    errMessage:_errMessage
  }
  }

  //如果没有对应用户
 
  
  





