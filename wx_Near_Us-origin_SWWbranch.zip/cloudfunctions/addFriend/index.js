// addFriend方法：
//1.先在数据库中查询该用户的好友列表，判断对应好友是否已存在；
//2.（1）如果存在，显示已添加；
//  （2）如果不存在，则调用add方法，将该好友添加到friendList中

const cloud = require('wx-server-sdk')

cloud.init()

//数据库对象
const db=cloud.database();
const _=db.command;
const $=db.command.aggregate;


exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext()
  console.log("测试号13");
  console.log("接收到的参数为————————————————————————————");
  console.log(event);
  console.log("打印好友的searchID————————————————————————");
  console.log(event.friend.searchID);

  // let IsExist=await db.collection("User_Public_Data").aggregate()
  // .project({
  //   included: $.in([wxContext.OPENID, '$OPList'])
  // }).end()

//先查询添加对象是否已在好友列表中
  let IsExist=await db.collection("user_info").aggregate()
  .match({
    openID:wxContext.OPENID
  })
  .project({
    included: $.in([event.friend.searchID, '$friend_searchID_List'])
  }).end();

  console.log("打印数据库查询结果————————————————————————");
  console.log(IsExist);
 console.log(IsExist.list[0].included);

  //如果已存在，直接返回
  if(IsExist.list[0].included) {
    return  {
      errMessage: 0       //返回代码0表示已存在
    }
  }   

  //如果不存在，则将其添加到好友列表中
  else{
    await db.collection("user_info").where({
      openID: wxContext.OPENID
    }).update({
      data:{
        friend_searchID_List: _.push({
          each:[event.friend.searchID],
        }),
        friendList:_.push({
          each:[event.friend]
        })
      }
    })

    return {
      errMessage: 1         //返回代码为1表示添加成功
    }
  }

}