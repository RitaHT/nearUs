

/**10.1
 * 这个云函数用于处理用户的登录
 * 根据数据库中是否有该用户的openID，分成两种情况：
 * 1.如果没有，则进入注册阶段：为其分配1个searchID，并将用户的数据记录到数据库里
 * 2.如果有，直接返回，不执行操作
 */

//cloud对象
const cloud = require('wx-server-sdk')

// 初始化 cloud
cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

//数据库、查询指令对象
const db=cloud.database();    
const _=db.command;
const $=db.command.aggregate;

exports.main = async (event, context) => {
 
  console.log("现在进入了login函数");
  console.log("测试号1");
 

   //获取微信上下文对象
  const wxContext = cloud.getWXContext()   
  
  //得到openID
  const openid=wxContext.OPENID;      

  console.log("event里面的数据————————————————————");
  console.log(event);
  console.log(event.nickName);
  console.log(event.avatarUrl);
  console.log(event.latitude);
  console.log(event.longitude);
console.log("event里的数据打印完毕—————————————————");
    
   //获取当前searchID(当前id值存于User_Public_Data数据库中，调用后自增1)
  var current_searchID;  
  
  //1.先判断用户的openID是否已存在
  //判断该用户的openid是否在User_Public_Data的OPList中,
  //并将判断结果返回给IsExist对象
  let IsExist=await db.collection("User_Public_Data").aggregate()
  .project({
    included: $.in([openid, '$OPList'])
  }).end()

  console.log("现在打印返回的对象——————————————");
  console.log(IsExist);
  console.log("打印完毕————————————————————————");

  console.log("现在打印返回的included————————————");
  console.log(IsExist.list[0].included);
  console.log("打印完毕————————————————————————");

  //如果用户的openID已存在，
  //则直接return，不执行任何操作
  if(IsExist.list[0].included==true){
    console.log("用户已存在！！！直接退出！！");
    return;
  }
  //////////////////////////////////////////////////////////


  //2.得到User_Public_Data中的当前searchID
    db.collection("User_Public_Data").doc("User_Public_Data000").get()
   .then(res=>{
     console.log("调用get返回的数据：————————————————————");
      console.log(res);
      current_searchID=res.data.searchID;

  console.log("打印当前openID！！！！！！！！！！！！！！！");
  console.log(openid);
  console.log("打印当前searchID!!!!!!!!!!!!!!!!!!");
  console.log(current_searchID);

    console.log("现在进入searchID自增环节！！！！！！！");

  //3.让库中的当前searchID自增1
     db.collection("User_Public_Data").doc("User_Public_Data000").update({
    data:{
      searchID:current_searchID+1 ,             //数据库中的searchID自增10
      OPList: _.push([openid])                  //将openID写入OPList中
    }
}).then(res=>{
    console.log("打印当前update的res———————————————————");
    console.log(res);
    console.log("打印完毕——————————————————————————————");
    console.log("searchID自增完成————————————————————");
    console.log("开始写入用户信息—————————————————————");

  //4.向数据库中写入用户信息
    db.collection("user_info").add({
    data:{
            openID:openid,                    //openID
            searchID:current_searchID,        //searchID
            nickName:event.nickName,          //昵称
            avatarUrl:event.avatarUrl,        //头像
            latitude:event.latitude,          //经度
            longitude:event.longitude,        //纬度
            friendList:[],                    //好友列表
            friend_searchID_List:[]           //好友searchID列表
          },
})
.then(res=>{
    console.log("打印add返回的res———————————————————");
    console.log(res);
    console.log("打印完毕——————————————————————————————");
        console.log("用户信息写入完毕");
  })
    }) 

  })
}

