/**常量类 */

//腾讯测试AK,请替换成自己申请的 AK
const tencentAk = 'P2KBZ-YH7WX-SLV42-ZEW2Y-GY3CV-SQFXF';

module.exports = {
  tencentAk: tencentAk
}